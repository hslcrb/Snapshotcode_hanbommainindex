


<!--templateType값 입력-->

<!--//templateType-->
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta property="og:title" content="한봄고등학교">
		<meta property="og:description" content="한봄고등학교 홈페이지에 오신 것을 환영합니다.">
		<meta name="description" lang="ko" content="한봄고등학교 홈페이지에 오신 것을 환영합니다.">
		<title>한봄고등학교</title>
		<link rel="stylesheet" href="/00_common/css/layout.css" media="all">
		<link rel="stylesheet" href="/00_common/css/template/T0021_layout.css" media="all">
		<link rel="stylesheet" href="/css/web/hanbom-h/layout_cnt.css" media="all">
		<link rel="stylesheet" href="/00_common/css/template/T0021.css" media="all">
		<link rel="stylesheet" href="/00_common/css/template/T0021_widget.css" media="all">
		<link rel="stylesheet" href="/00_common/css/up_pop.css" media="all">
		<link rel="stylesheet" href="/css/web/hanbom-h/main_cnt.css" media="all">
		
		

		<script src="/00_common/js/jquery.min.js"></script>
		<script src="/00_common/js/slick.min.js"></script>
		<script src="/00_common/js/modernizr-2.6.2.min.js"></script>
		<script src="/00_common/js/common.js"></script>
		<script src="/00_common/js/con_com.js"></script>
		<script src="/00_common/js/jquery.bxslider.js"></script>
		
		<script src="/js/template/T0021/main.js"></script>


		<!-- 위젯 002  -->
	    <script src="/js/common.js"></script> <!-- 팝업  -->
	    <link rel="stylesheet" href="/css/com/jquery/jquery-ui.min.css"> <!-- 팝업  -->
	    <script src="/js/jquery-ui.min.js"></script> <!-- 팝업  -->
	    <script src="/js/jquery.form.min.js"></script><!-- ajaxSubmit function 사용-->
	    <script src="/js/jquery.bpopup.min.js"></script><!-- .bPopup({}) function 사용 -->
	    <!-- //위젯 002  -->
	    
	    <!-- 개발자 추가 -->
	    <script src="/js/co/js_developer.js"></script><!-- 개발자 js -->
	    <!-- //개발자 추가 -->
	</head>
	<body>
		<!-- 바로가기 -->
		<div id="skipArea">
			<a href="#container">본문으로 바로가기</a><a href="#gnb">메인메뉴 바로가기</a>
		</div>
		<!-- //바로가기 -->

		<!-- 팝업 자세히보기 -->
		




<!-- 상단팝업 자세히 보기 -->

<!-- // 상단팝업 자세히 보기 -->


<!-- 일반팝업 -->

	<div id="popupNormal3025" style="display:none;">
		
		
		
			<a href="https://www.goedu.kr/bbs/2/view/55" rel="noopener noreferrer" target="_blank" title="새창열림">
				<img src="/upload/goesw/pm/2026/02/9a2e3a3e-1826-4a2e-8932-ea91080b0474.jpg" width="738" height="451" alt=""/>
			</a>
		
		
		<!-- <div style="background-color:#3b568f; height:20px; text-align:right; width:100%"> -->
		<div class="popBtns">
			<a href="javascript:" class="popupCookieSet" data-seq="3025" data-closepd="1">1일동안 열지 않음   <i class="xi-close-circle-o" aria-hidden="true"></i></a>
		</div>
	</div>

	<div id="popupNormal2572" style="display:none;">
		
		
		
			<a href="#"  >
				<img src="/upload/goesw/pm/2026/02/82afe3ad-12af-4a8f-b6a1-4439d9f27a70.png" width="708" height="536" alt=""/>
			</a>
		
		
		<!-- <div style="background-color:#3b568f; height:20px; text-align:right; width:100%"> -->
		<div class="popBtns">
			<a href="javascript:" class="popupCookieSet" data-seq="2572" data-closepd="1">1일동안 열지 않음   <i class="xi-close-circle-o" aria-hidden="true"></i></a>
		</div>
	</div>

<!-- //팝업 자세히 보기 -->

<script>
// 팝업 창 타입 띄우기
$(document).ready(function() {
	

	
	
	

	
	
		
	

	var popupWidthLc = parseInt(700);
	var popupheightLc = parseInt(0);

	var usePopYN = getCookie("popCookie3025");
	if (usePopYN != "hide") {
		$("#"+"popupNormal3025").dialog({
			dialogClass: "normalPopup",
		    autoOpen: true,
		    modal: false,
		    resizeable : false,
		    title: "교육용 클라우드 지원시스템 이용안내(새창열림)",
		    width: 'auto',
		    height: 'auto',
		    show:{
		  		effect:"blind",
		  		duration: 100
		    },
		    hide:{
		   	 	effect:"blind",
		   	 	duration: 100
		    },
		    position: {my:'left+'+popupWidthLc+' top+'+popupheightLc+'', at: 'left top'}
		}).dialog('open');
	}
	

	
	
	

	
	

	var popupWidthLc = parseInt(0);
	var popupheightLc = parseInt(0);

	var usePopYN = getCookie("popCookie2572");
	if (usePopYN != "hide") {
		$("#"+"popupNormal2572").dialog({
			dialogClass: "normalPopup",
		    autoOpen: true,
		    modal: false,
		    resizeable : false,
		    title: "학교 홈페이지 신규오픈 안내",
		    width: 'auto',
		    height: 'auto',
		    show:{
		  		effect:"blind",
		  		duration: 100
		    },
		    hide:{
		   	 	effect:"blind",
		   	 	duration: 100
		    },
		    position: {my:'left+'+popupWidthLc+' top+'+popupheightLc+'', at: 'left top'}
		}).dialog('open');
	}
	

  	normalPopupKeyupEvent = function(e){
		if(e.keyCode == 13){
			var normalPopup = $(".normalPopup:visible .ui-widget-content");
			$(this).css("display","none");
			$("a[href='#container']").focus();
		} else if (e.keyCode == 27){
			var normalPopup = $(".normalPopup:visible .ui-widget-content");
			$("a[href='#container']").focus();
		}
	}
	var el = document.querySelector(".normalPopup");
	if(el){
		document.querySelector(".normalPopup .ui-dialog-titlebar-close").addEventListener("keyup",normalPopupKeyupEvent);
		document.querySelector(".normalPopup").addEventListener("keydown",normalPopupKeyupEvent);
	}
});
</script>
		<!-- //팝업 자세히보기  -->

		<div id="wrap" > <!--[D] 팝업이 있을때 #wrap에 클래스 openPop 추가-->
			<!-- [P] 메인페이지인 경우에만 생성되는 조건식 -->
			<!-- 상단팝업 -->
			


			<!-- 템플릿-메인 미리보기 외 홈페이지  -->
			
				
			
			
			<!-- 템플릿-메인 미리보기  -->
			

			<!-- //상단팝업 -->
			<!-- 헤더-->
			





	
		<div id="timeLoadingView"></div>
	
			<header id="header">
				<div class="header_wrap container">
					<h1>
						<a href="/hanbom-h/main.do">
							<!--LST-->
						<img src="/images/web/hanbom-h/common/logo.png" alt="한봄고등학교">
							<!--LED-->
						</a>
					</h1>
					<div class="topUtil">
						<div class="util_wrap">
							













						<a href="/hanbom-h/main.do">홈</a>
						<ul class="user">
							
								
								
										
											
											
												<li class="name">이호세 (livers_jose)</li>
											
										
										<li>
											<input type="hidden" id="timeLimit" value="30">
											<a href="/hanbom-h/lo/login/logout.do" title="로그아웃">로그아웃</a></li>
										
											<li><a href="/hanbom-h/sb/sbscrb/selectSbscrbInfo.do" title="마이페이지">마이페이지</a></li>
										
										
								
							
						</ul>
						
						<ul class="util">
							<li><a href="/hanbom-h/sitemap.do">사이트맵</a></li>
							
							
						</ul>

						</div>
						
						<div class="totalSearch">
							<form name="searchForm" id="searchForm" method="POST" target="_blank">
								<input type="text" placeholder="검색어를 입력해주세요" name="qt" id="total_search" title="검색어를 입력해주세요">
								<input type="hidden" name="sysId" value="hanbom-h"> <!-- 검색엔진 sysId필수값 -->
								<button type="button" onClick="javascript:goSearchForm();" title="새창열림"><i class="xi-search" aria-hidden="true"></i></button>
							</form>
						</div>
					</div>
					<!-- moblie button-->
						<a href="javascript:" class="mBtn mNav" id="mNavOpen" title="모바일메뉴 열기"><i class="xi-bars" aria-hidden="true"></i></a>
						<a href="javascript:" class="mBtn mSearch" id="mSearchOpen" title="모바일검색 열기"><i class="xi-search" aria-hidden="true"></i></a>
					<!-- //moblie button-->
				</div>
					<!-- NAV : fullDown / oneDown / oneFull -->
					<div id="nav" class="oneDown">
						<div id="blind"></div>
						<div id="gnb">
							<!--  depWidth : 1차 depth width 자동계산-->
							<!--START-->
							
							<div class="depth01 depWidth">
								<ul>
									<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=16957&cntntsId=3476"  ><span>학교소개</span></a>
										<div class="depth02">
										<ul>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=16957&cntntsId=3476"  ><span>한봄교육가족 인사말</span></a></li>
											<li><a href="/hanbom-h/hm/hist/selectHistList.do?mi=16962"  ><span>학교연혁</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17012&cntntsId=3194"  ><span>교육목표</span></a></li>
											<li><a href="/hanbom-h/ss/schulSymbol/selectSongSymbolInfo.do?mi=17015"  ><span>학교상징</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17020&cntntsId=3195"  ><span>학교현황</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17027&cntntsId=3196"  ><span>중심노력점 및 특색사업</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17036&cntntsId=3198"  ><span>교직원소개</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17039&cntntsId=3199"  ><span>배구부소개</span></a></li>
											<li><a href="/hanbom-h/lm/location/locationMapView.do?mi=17045"  ><span>전화 및 교통안내</span></a></li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17074&cntntsId=3202"  ><span>입학안내</span></a>
										<div class="depth02">
										<ul>
											<li><a id="17056" href="#?mi=17056"  ><span>학과소개</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17074&cntntsId=3202"  ><span>뷰티아트과</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17083&cntntsId=3203"  ><span>캐릭터창작과</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17087&cntntsId=3205"  ><span>시각디자인과</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17090&cntntsId=3206"  ><span>사운드디자인과</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17092&cntntsId=3207"  ><span>빅데이터정보과</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17095&cntntsId=3208"  ><span>스마트제어과</span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17105" href="#?mi=17105"  ><span>모집요항</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17124&cntntsId=3477"  ><span>신입생 전형요항</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17125&bbsId=9974"  ><span>진로적성 특별전형</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17129&cntntsId=3210"  ><span>장학제도</span></a></li>
											<li><a id="17156" href="#?mi=17156"  ><span>학교홍보</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17161&cntntsId=3482"  ><span>입학 e-브로셔</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17167&cntntsId=3484"  ><span>학교 홍보 동영상</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17172&bbsId=10010"  ><span>학생작품 및 수상내역</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17187&bbsId=10022"  ><span>한봄 NEWS</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17225&bbsId=10045"  ><span>학과체험</span></a></li>
											<li><a id="17231" href="#?mi=17231"  ><span>입학상담</span></a>
												<div class="depth03">
												<ul>
													<li><a href="https://docs.google.com/forms/d/1rVHOBfd4WkVxuOPDugs6uAh2CHlJP2559WAyi3mgTr8/viewform?edit_requested=true"   rel="noopener noreferrer" target="_blank" title="새창열림" ><span>방문 입학상담</span></a></li>
													<li><a href="https://pf.kakao.com/_kKHxixb"   rel="noopener noreferrer" target="_blank" title="새창열림" ><span>카카오톡 상담</span></a></li>
												</ul>
												</div>
											</li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17249&bbsId=10062"  ><span>학교생활</span></a>
										<div class="depth02">
										<ul>
											<li><a id="17247" href="#?mi=17247"  ><span>알림</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17249&bbsId=10062"  ><span>공지사항</span></a></li>
													<li><a href="/hanbom-h/ps/schdul/selectSchdulMainList.do?mi=17250"  ><span>월중행사</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17252&bbsId=10063"  ><span>가정통신문</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17254&bbsId=10064"  ><span>가정통신문(교육청)</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17255&bbsId=10065"  ><span>공모전 및 모집공고</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17256&bbsId=10066"  ><span>보건알림</span></a></li>
													<li><a href="/hanbom-h/ad/fm/foodmenu/selectFoodMenuView.do?mi=17258"  ><span>오늘의 식단</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17262&bbsId=10070"  ><span>교육과정</span></a></li>
											<li><a id="17263" href="#?mi=17263"  ><span>학생자치회</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17266&cntntsId=3218"  ><span>학생자치회 조직</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17268&cntntsId=3486"  ><span>학생생활규정</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17273&bbsId=10074"  ><span>학생생활규정게시판</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17276&bbsId=10075"  ><span>봉사활동</span></a></li>
											<li><a id="17279" href="#?mi=17279"  ><span>동아리활동</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17281&cntntsId=3223"  ><span>동아리활동</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17286&bbsId=10080"  ><span>동아리활동 사진</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17288&bbsId=10081"  ><span>방과후학교</span></a></li>
											<li><a id="17290" href="#?mi=17290"  ><span>학교특색활동</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17292&bbsId=10082"  ><span>학교특색활동</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17298&bbsId=10085"  ><span>뷰티아트과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17300&bbsId=10087"  ><span>캐릭터창작과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17303&bbsId=10089"  ><span>시각디자인과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17305&bbsId=10091"  ><span>빅데이터정보과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17307&bbsId=10092"  ><span>스마트제어과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17310&bbsId=10094"  ><span>사운드디자인과</span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17318" href="#?mi=17318"  ><span>자격증정보</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17322&cntntsId=3228"  ><span>전문 자격증 취득 일정 </span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17325&cntntsId=3230"  ><span>기능장 제도 안내</span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17330" href="#?mi=17330"  ><span>학교급식안내</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/ad/fm/foodmenu/selectFoodMenuView.do?mi=17347"  ><span>오늘의 식단</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17364&bbsId=10112"  ><span>급식게시판</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17371&bbsId=10115"  ><span>영양상담</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17378&bbsId=10118"  ><span>축산물이력표시</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17381&bbsId=10120"  ><span>교육활동침해 에방교육계획</span></a></li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17394&cntntsId=3248"  ><span>취업/진학</span></a>
										<div class="depth02">
										<ul>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17394&cntntsId=3248"  ><span>현장실습 및 채용의뢰</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17400&bbsId=10131"  ><span>취업현황</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17404&bbsId=10133"  ><span>취업자료</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17413&bbsId=10136"  ><span>진로진학자료</span></a></li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17438&bbsId=10155"  ><span>학습지원센터</span></a>
										<div class="depth02">
										<ul>
											<li><a id="17435" href="#?mi=17435"  ><span>교과자료실</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17438&bbsId=10155"  ><span>보통교과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17441&bbsId=10158"  ><span>뷰티아트과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17446&bbsId=10160"  ><span>캐릭터창작과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17450&bbsId=10163"  ><span>시각디자인과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17457&bbsId=10169"  ><span>빅데이터정보과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17465&bbsId=10176"  ><span>스마트제어과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17470&bbsId=10179"  ><span>사운드디자인과</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="https://read365.edunet.net/PureScreen/SchoolSearch?schoolName=%ED%95%9C%EB%B4%84%EA%B3%A0%EB%93%B1%ED%95%99%EA%B5%90&provCode=J10&neisCode=J100000653"   rel="noopener noreferrer" target="_blank" title="새창열림" ><span>독서로(학교도서관 도서 검색)</span></a></li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17489&bbsId=10188"  ><span>커뮤니티</span></a>
										<div class="depth02">
										<ul>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17489&bbsId=10188"  ><span>각종양식[서식]</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17539&bbsId=10225"  ><span>재학생게시판</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17546&bbsId=10231"  ><span>학부모게시판</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17550&bbsId=10234"  ><span>교사게시판</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17559&bbsId=10240"  ><span>건의게시판</span></a></li>
											<li><a id="17564" href="#?mi=17564"  ><span>사이버상담실</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17569&bbsId=10247"  ><span>상담자료실</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17573&bbsId=10250"  ><span>친구문제</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17609&bbsId=10278"  ><span>성희롱,성폭력 사이버신고센터</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17613&bbsId=10281"  ><span>한봄앨범</span></a></li>
											<li><a href="https://cafe.daum.net/suwonhanil"  ><span>총동창회</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17623&bbsId=10288"  ><span>성적민원센터</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17625&bbsId=10289"  ><span>학교생활 민원센터</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17627&bbsId=10291"  ><span>학생선수고충처리센터</span></a></li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17654&bbsId=10302"  ><span>공개코너</span></a>
										<div class="depth02">
										<ul>
											<li><a id="17650" href="#?mi=17650"  ><span>법인</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17654&bbsId=10302"  ><span>정관</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17657&bbsId=10304"  ><span>임원 인적사항(임원과 친족관게에 있는 교직원 현황)</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17660&bbsId=10306"  ><span>예.결산</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17662&bbsId=10307"  ><span>이사회회의록</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17667&bbsId=10310"  ><span>법정부담금 납부 현황</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17670&bbsId=10311"  ><span>사무직원인사관리지침 </span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17685" href="#?mi=17685"  ><span>예.결산현황</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17687&bbsId=10320"  ><span>예산서</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17690&bbsId=10322"  ><span>결산서</span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17695" href="#?mi=17695"  ><span>업무추진비 집행내역</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17698&bbsId=10326"  ><span>업무추진비 집행내역</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17701&bbsId=10328"  ><span>신용카드 사용내역</span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17706" href="#?mi=17706"  ><span>물품 및 공사계약</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17711&bbsId=10336"  ><span>수의 계약내역</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17715&bbsId=10339"  ><span>입찰공고</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17718&bbsId=10342"  ><span>입찰결과</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17722&bbsId=10346"  ><span>물품선정위원회</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17732&bbsId=10354"  ><span>상품권 구매 및 사용 내역</span></a></li>
											<li><a id="17737" href="#?mi=17737"  ><span>수익자부담 경비집행내역</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17739&bbsId=10357"  ><span>방과후학교</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17741&bbsId=10358"  ><span>수학여행</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17745&bbsId=10362"  ><span>체험학습</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17747&bbsId=10364"  ><span>수련회선정</span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17752" href="#?mi=17752"  ><span>학교발전기금</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17754&cntntsId=3277"  ><span>학교발전기금</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17758&bbsId=10369"  ><span>운용계획</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17763&bbsId=10373"  ><span>접수 및 집행내역</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17766&bbsId=10376"  ><span>결산보고서</span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17770" href="#?mi=17770"  ><span>학교운영위원회</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17772&cntntsId=3279"  ><span>학교운영위원회란?</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17773&cntntsId=3280"  ><span>구성현황</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17777&cntntsId=3282"  ><span>운영규정</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17780&bbsId=10384"  ><span>학교운영위원회게시판</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17785&bbsId=10387"  ><span>학부모 의견수렴</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17790&bbsId=10390"  ><span>교원인사위원회</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17797&bbsId=10392"  ><span>감사결과</span></a></li>
											<li><a href="https://read365.edunet.net/PureScreen/SchoolSearch?schoolName=%ED%95%9C%EB%B4%84%EA%B3%A0%EB%93%B1%ED%95%99%EA%B5%90&provCode=J10&neisCode=J100000653"   rel="noopener noreferrer" target="_blank" title="새창열림" ><span>학교알리미</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17806&bbsId=10397"  ><span>학교운동부집행내역</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17811&bbsId=10402"  ><span>기타</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17813&bbsId=10404"  ><span>석면해체제거공사</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17814&bbsId=10405"  ><span>학교평가</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17817&bbsId=10408"  ><span>공기정화장치 점검</span></a></li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17824&cntntsId=3287"  ><span>행정서비스</span></a>
										<div class="depth02">
										<ul>
											<li><a id="17822" href="#?mi=17822"  ><span>증명서 발급</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17824&cntntsId=3287"  ><span>증명서발급안내</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17826&bbsId=10414"  ><span>증명서 Q&amp;A</span></a></li>
												</ul>
												</div>
											</li>
											<li><a id="17827" href="#?mi=17827"  ><span>학교시설개방</span></a>
												<div class="depth03">
												<ul>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17829&bbsId=10416"  ><span>학교시설개방 Q&amp;A</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17832&cntntsId=3288"  ><span>이용수칙</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17836&cntntsId=3290"  ><span>사용료</span></a></li>
													<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17840&bbsId=10422"  ><span>사용신청</span></a></li>
													<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17858&cntntsId=3294"  ><span>시설 개방 및 사용 허가 현황</span></a></li>
												</ul>
												</div>
											</li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17863&cntntsId=3295"  ><span>학교행정서비스 헌장</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17866&bbsId=10430"  ><span>행정정보공개</span></a></li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17896&cntntsId=3487"  ><span>학교특색사업</span></a>
										<div class="depth02">
										<ul>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17896&cntntsId=3487"  ><span>특성화고 미래역량강화사업</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17899&cntntsId=3488"  ><span>산학일체형도제학교운영</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17901&cntntsId=3490"  ><span>수원형 도제학교</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17903&cntntsId=3491"  ><span>중소기업특성화고</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17907&cntntsId=3492"  ><span>사이버가디언즈</span></a></li>
											<li><a href="/hanbom-h/na/ntt/selectNttList.do?mi=17909&bbsId=10450"  ><span>예술중점학교 (예술활동형)</span></a></li>
											<li><a href="/hanbom-h/cm/cntnts/cntntsView.do?mi=17914&cntntsId=3493"  ><span>과정평가형 자격 교육과정</span></a></li>
										</ul>
										</div>
									</li>
									<li><a href="/hanbom-h/presnatn/selectPresnatnHmpgList.do?mi=17916"  ><span>결과 조회</span></a></li>
								</ul>
							</div>
							<!--END-->
						</div>
					</div>
					<!-- //NAV : fullDown / oneDown / oneFull -->

					<!-- 팝업영역 열기/닫기 버튼 -->
					
		</header>
		<!-- //header -->
					<!-- moblie NAV -->
					<div id="mNav">
						<h1>전체메뉴</h1>
						<div class="snb"></div>
						<nav id="mgnb"></nav>
						<p><a href="" id="mNavClose" title="모바일 메뉴 닫기"><i class="xi-close" aria-hidden="true"></i></a></p>
					</div>


			<!-- //헤더 -->
			<!-- container -->
			



<!--templateType값 입력-->

<!--//templateType-->
<!-- 컨테이너 -->
<div id="container">
	<!-- MC_wrap1 -->
	<div class="MC_wrap1">
		<div class="container">
			<div class="MC_box1 widgEdit" data-id="10" data-ty="MAINIMG">
				<!-- 메인비주얼 -->
				<div class="MVisual0021 visual">
					<div class="slider" id="visualSlide">
						
							
							
								
									<p class="item">
										<img src="/upload/hanbom-h/widg/img_241074aa-ad94-4e7e-ab13-2a4cce7d87a1cdcaf9150c3661542401.png" alt="&amp;amp;amp;amp;quot;K-CONTENTS&amp;amp;amp;amp;quot; 인재의 요람 한봄고등학교">
									</p>
								
							
						
					</div>
					<div class="control">
						<a href="" class="prev">
							<span class="hid">비주얼 이전</span><i class="xi-angle-left" aria-hidden="true"></i>
						</a>
						<a href="" class="stop">
							<span class="hid">비주얼 정지</span><i class="xi-pause" aria-hidden="true"></i>
						</a>
						<a href="" class="play">
							<span class="hid">비주얼 재생</span><i class="xi-play" aria-hidden="true"></i>
						</a>
						<a href="" class="next">
							<span class="hid">비주얼 다음</span><i class="xi-angle-right" aria-hidden="true"></i>
						</a>
					</div>
				</div>
				<!-- //메인비주얼 -->
			</div>
		</div>
	</div>
	<!-- //MC_wrap1 -->

	<!-- MC_wrap2 -->
	<div class="MC_wrap2 " >
		<div class="container">
			<div class="MC_box3 widgEdit" data-id="30" data-ty="BBS" data-tab="3" data-ntt="2">
				<!-- 게시판 -->
				<div class="notice0021">
					<div class="titTab">
						<ul>
							<li><a href="#notice1">
									<span>&nbsp;</span>
								</a></li>
						</ul>
					</div>
					<div class="tabWrap">
						<div class="list_box on" id="notice1">
							<ul>
								<!-- 데이타가 없는경우 아래의 내용만 출력해주세요! -->
								<li class="no_data">연결된 위젯 데이터가 없거나 호출 중입니다.</li>
							</ul>
							<a href="" class="btn_more btnTy1">
								<em>더보기</em><img src="/images/web/hanbom-h/main/0021_btn_more.png" alt="">
							</a>
						</div>
					</div>
				</div>
				<!-- //게시판 -->
			</div>

			<div class="MC_box4 widgEdit" data-id="50" data-ty="POPUP">
				<!-- 팝업존 -->
				<div class="pop0021 popupZone">
					<h2>&nbsp;</h2>
					<div class="pop_img" id="popupSlide">
						
							
								<p class="item">
									<a href="" title="새창" target="_blank">
										<img src="/images/template/T0021/main/0021_popup.jpg" alt="홈페이지를 새롭게 리뉴얼 하였습니다.">
									</a>
								</p>
								<p class="item">
									<a href="" title="새창" target="_blank">
										<img src="/images/template/T0021/main/0021_popup.jpg" alt="홈페이지를 새롭게 리뉴얼 하였습니다.">
									</a>
								</p>
							
							
						
					</div>
					<div class="control arwShow">
						<p class="page">
							<strong></strong><span></span>
						</p>
						<a href="" class="prev">
							<i class="xi-arrow-left" aria-hidden="true"></i><span class="hid">팝업존 이전</span>
						</a>
						<a href="" class="stop">
							<i class="xi-pause" aria-hidden="true"></i><span class="hid">팝업존 정지</span>
						</a>
						<a href="" class="play">
							<i class="xi-play" aria-hidden="true"></i><span class="hid">팝업존 재생</span>
						</a>
						<a href="" class="next">
							<i class="xi-arrow-right" aria-hidden="true"></i><span class="hid">팝업존 다음</span>
						</a>
					</div>
				</div>
				<!-- //팝업존 -->
			</div>

			<div class="MC_box5 widgEdit" data-id="60" data-ty="SCHDUL">
				<!-- 캘린더 -->
				<div class="pop_schedule0021">
					<input type="hidden" id="sYear" value="2026" /> <input type="hidden" id="sMonth" value="3" />
					<div class="tit_wrap">
						<h2>&nbsp;</h2>
						<span class="date">&nbsp;<em>&nbsp;</em></span>
					</div>
					<div class="sche_wrap">
						<div class="sche_list">
							<a href="javascript:" class="prev" onclick="setCalenDar('preM')">
								<i class="xi-arrow-left" aria-hidden="true"></i><em class="hid">이전달</em>
							</a>
							<ul></ul>
							<a href="javascript:" class="next" onclick="setCalenDar('nextM')">
								<i class="xi-arrow-right" aria-hidden="true"></i><em class="hid">다음달</em>
							</a>
						</div>
						<ul class="lst">
							<li class="no_data">&nbsp;</li>
						</ul>
					</div>
					<a href="" class="btn_more btnTy2">
						<em class="hid">일정 더보기</em>
					</a>
				</div>
				<!-- //캘린더 -->
			</div>
		</div>
	</div>
	<!-- //MC_wrap2 -->

	<!-- MC_wrap3 -->
	<div class="MC_wrap3">
		<div class="container">
			<div class="MC_box2 widgEdit" data-id="20" data-ty="BANNER" data-tab="7">
				<!-- 바로가기1 -->
				<div class="M_link0021">
					<h2 class="hid">바로가기</h2>
					<ul>
						<li>
							<a href="">
							<span class="img"></span>
							<p><span>&nbsp;</span></p>
							</a>
						</li>
						<li>
							<a href="">
							<span class="img"></span>
							<p><span>&nbsp;</span></p>
							</a>
						</li>
						<li>
							<a href="">
							<span class="img"></span>
							<p><span>&nbsp;</span></p>
							</a>
						</li>
						<li>
							<a href="">
							<span class="img"></span>
							<p><span>&nbsp;</span></p>
							</a>
						</li>
						<li>
							<a href="">
							<span class="img"></span>
							<p><span>&nbsp;</span></p>
							</a>
						</li>
						<li>
							<a href="">
							<span class="img"></span>
							<p><span>&nbsp;</span></p>
							</a>
						</li>
						<li>
							<a href="">
							<span class="img"></span>
							<p><span>&nbsp;</span></p>
							</a>
						</li>
					</ul>
				</div>
				<!-- //바로가기1 -->
			</div>

			<div class="MC_box6 widgEdit" data-id="40" data-ty="GALBBS" data-tab="1" data-ntt="2">
				<!-- 갤러리 -->
				<div class="gallery0021">
					<h2>&nbsp;</h2>
					<div class="list_box">
						<ul>
							<!-- 데이터가 없는경우 아래의 내용만 출력해주세요! -->
							<li class="no_data">연결된 위젯 데이터가 없거나 호출 중입니다.</li>
						</ul>
					</div>
					<a href="" class="btn_more btnTy1">
						<em class="hid">&nbsp;</em><em>더보기</em><img src="/images/web/hanbom-h/main/0021_btn_more.png" alt="">
					</a>
				</div>
				<!-- //갤러리 -->
			</div>

			<div class="MC_box7 widgEdit" data-id="70" data-ty="DIET">
				<!-- 식단 -->
				<div class="meal_menu0021">
					<h2>&nbsp;</h2>
					<div class="inner">
						<ul >
							
								
									<li class="no_data">연결된 식단메뉴가 없습니다.</li>
								
								
								
							
						</ul>
						<img src="/images/template/T0021/main/0021_meal.png" alt="">
					</div>
					<a href="" class="btn_more btnTy2">
						<em class="hid">오늘의 식단 더보기</em>
					</a>
				</div>
				<!-- //식단 -->
			</div>
		</div>
	</div>
	<!-- //MC_wrap3 -->

	<!-- 배너존 -->
	<div class="banner_zone">
		<div class="container">
			<h2>배너모음</h2>
			<p class="btn arwShow">
				<a href="#bannerPrev" class="prev" title="배너 이전">
					<i class="xi-angle-left" aria-hidden="true"></i>
				</a>
				<a href="#bannerStop" class="stop" title="배너 정지">
					<i class="xi-pause" aria-hidden="true"></i>
				</a>
				<a href="#bannerStop" class="play" title="배너 재생">
					<i class="xi-play" aria-hidden="true"></i>
				</a>
				<a href="#bannerNext" class="next" title="배너 다음">
					<i class="xi-angle-right" aria-hidden="true"></i>
				</a>
				<a href="#bannerList" class="list dialogAllBannerList" onClick="bannerListAct('hanbom-h')" title="배너 리스트">
					<i class="xi-bars" aria-hidden="true"></i>
				</a>
			</p>
			<div class="bnWrap" id="bnSlider">
				
					
						<p class="item"><a href="https://www.teachforkorea.go.kr/home/kor/main.do" target="_blank"><img src="/images/template/T0021/main/ban_01.gif" alt="교육기부 바로가기"></a></p>
						<p class="item"><a href="https://www.simpan.go.kr/nsph/index.do" target="_blank"><img src="/images/template/T0021/main/ban_02.gif" alt="온라인행정심판 바로가기"></a></p>
						<p class="item"><a href="https://www.parents.go.kr/index.do" target="_blank"><img src="/images/template/T0021/main/ban_04.gif" alt="학부모On누리 바로가기"></a></p>
						<p class="item"><a href="https://www.ebsi.co.kr/ebs/pot/poti/main.ebs" target="_blank"><img src="/images/template/T0021/main/ban_05.gif" alt="EBSi 바로가기"></a></p>
					
					
				
			</div>
		</div>
	</div>
	<!--// 배너존 -->
</div>
<!-- //컨테이너 -->
<!-- 위젯 출력 -->




<script>
	// js 공통 스크립트에 포함 ( 메인호출시 사용되는 js에 포함해야함 )
	widgApiCall = function(widgSysId, widgId, callBackFn){
		$.ajax({
			type: "post",
			url: "/hanbom-h/widgApi/get/json.do",
			dataType: "json",
			data: {
				widgId : widgId,
				widgSysId : widgSysId
			},
			success:function(result){
				callBackFn(result);
			},
			error:function(data) {
				console.log("오류가 발생하였습니다.\n관리자에게 문의하세요.");
				console.log("result : " + data);
			}

		});
	}

	// 메인 호출 후 실행되도록 스크립트 추가
	$(document).ready(function(){
		var sysId = "hanbom-h";

		// 파라미터 - 시스템아이디, 위젯아이디, 콜백함수
		/* widgApiCall(sysId, '10', apiFnMainImg); // 메인 비주얼 */
		widgApiCall(sysId, '20', apiFnLink); // 바로가기 배너
		widgApiCall(sysId, '30', apiFnBbs); // 일반 게시판
		widgApiCall(sysId, '31', apiFnBbs); // 일반 게시판
		widgApiCall(sysId, '40', apiFnGalBbs); // 갤러리 게시판

		/* 위젯으로 제목만 변경. 제목이 없으면 추가할 필요없음 [실제 내용은 /sysId/main.do 에서 넘어온 데이터로 가공해서 처리] */
		widgApiCall(sysId, '50', apiFnPop); // 팝업존
		widgApiCall(sysId, '60', apiFnSchdul); // 일정
		widgApiCall(sysId, '70', apiFnDiet); // 식단
		/*//위젯으로 제목만 변경 [실제 내용은 /sysId/main.do 에서 넘어온 데이터로 가공해서 처리] */
		
		
		
	});

	// 메인 비주얼
	apiFnMainImg  = function(retDataList){
		var widgDataList = retDataList.widgDataList;
		var appendHtml = "";

		if (typeof widgDataList == "undefined" || widgDataList == null || widgDataList == "") {
			return false;
		} else {
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > ul").children().remove();

			for(idx=0; idx<widgDataList.length; idx++){
				appendHtml += "	<li><img src=\"" + widgDataList[idx].widgDataFlpth + "\" alt=\"" + widgDataList[idx].widgDataAltrtvText + "\"></li>";
			}

			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > ul").append(appendHtml);
		}
	}

	// 바로가기 배너
	apiFnLink  = function(retDataList){
		var widgDataList = retDataList.widgDataList;
		var appendHtml = "";

		if (typeof widgDataList == "undefined" || widgDataList == null || widgDataList == "") {
			return;
		} else {
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > ul").children().remove();

			for (idx = 0; idx < widgDataList.length; idx++) {
				appendHtml += "	<li>";
				appendHtml += "		<a href=\"" + widgDataList[idx].widgDataUrl + "\" target=\"" + widgDataList[idx].widgDataUrlTrgt + "\">";
				appendHtml += "			<span class='img'>";
				appendHtml += "				<img src=\"" + widgDataList[idx].widgDataFlpth + "\" alt=\"" + widgDataList[idx].widgDataAltrtvText + "\">";
				appendHtml += "			</span>";
				appendHtml += "			<p><span>" + widgDataList[idx].widgDataSj + "</span></p>";
				appendHtml += "		</a>";
				appendHtml += "	</li>";
			}

			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > ul").append(appendHtml);
		}
	}

	// 게시판
	apiFnBbs = function(retDataList) {
		var widgDataList = retDataList.widgDataList;
		var appendHtml = "";
		if (typeof widgDataList == "undefined" || widgDataList == null || widgDataList == "") {
			return false;
		} else {
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div").children().remove();
			
			appendHtml += "<div class='titTab'>";
			appendHtml += "	<ul>";
			for (idx = 0; idx < widgDataList.length; idx++) {
				if (idx == 0) { // current(첫번째 게시판) 분기처리
					appendHtml += "<li><a href='#notice" + Number(idx+1) + "' target='' class='current setNoticeWidg' data-bbs='" + widgDataList[idx].widgDataId + "' data-row='" + widgDataList[idx].widgDataCo + "'><span>" + widgDataList[idx].widgDataSj + "</span></a></li>";
				} else {
					appendHtml += "<li><a href='#notice" + Number(idx+1) + "' target='' class='setNoticeWidg' data-bbs='" + widgDataList[idx].widgDataId + "' data-row='" + widgDataList[idx].widgDataCo + "'><span>" + widgDataList[idx].widgDataSj + "</span></a></li>";
				}
			}
			appendHtml += "	</ul>";
			appendHtml += "</div>";
			appendHtml += "<div class='tabWrap'>";
			appendHtml += "</div>";
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div").append(appendHtml);
			nttListAction(retDataList.widgInfo.widgId);
		}
	}

	// 갤러리 게시판
	apiFnGalBbs = function(retDataList) {
		var widgDataList = retDataList.widgDataList;
		var appendHtml = "";

		if (typeof widgDataList == "undefined" || widgDataList == null || widgDataList == "") {
			return false;
		} else {
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div").children().remove();
			appendHtml += "<h2>"+widgDataList[0].widgDataSj+"</h2>";
			appendHtml += "<div class='list_box setNttlist setNoticeWidg' data-bbs='" + widgDataList[0].widgDataId + "' data-row='" + widgDataList[0].widgDataCo + "'>";
			appendHtml += "</div>";
			appendHtml += "<a href='' class='btn_more btnTy1'><em class='hid'>"+widgDataList[0].widgDataSj+"</em><em>더보기</em><img src='/images/template/T0021/main/0021_btn_more.png' alt=''></a>";
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div").append(appendHtml);
			galNttListAction(widgDataList);
		}
	}

	// 팝업존 [제목만 변경]
	apiFnPop = function(retDataList) {
		var widgDataList = retDataList.widgDataList;
		var appendHtml = "";

		if (typeof widgDataList == "undefined" || widgDataList == null || widgDataList == "") {
			appendHtml += "팝업존";
			$('.pop0021 > h2').html(appendHtml);
		} else {
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > h2").empty();
			appendHtml += "" + widgDataList[0].widgDataSj + "";
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > h2").append(appendHtml);
		}

		// 후 처리 : 컨트롤러에서 보내준 데이터를 JSTL로 가공
	}

	// 일정 [제목만 변경]
	apiFnSchdul = function(retDataList) {
		setCalenDar("curM");
		var widgDataList = retDataList.widgDataList;
		var appendHtml = "";

		if (typeof widgDataList == "undefined" || widgDataList == null || widgDataList == "") {
			appendHtml += "행사일정";
			$('.pop_schedule0021 > div > h2').html(appendHtml);
		} else {
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > div > h2").empty();
			appendHtml += "" + widgDataList[0].widgDataSj + "";
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > div > h2").append(appendHtml);
			$(".pop_schedule0021").find('.btn_more').attr('target', widgDataList[0].widgDataUrlTrgt);
		}
	}

	// 식단 [제목만 변경]
	apiFnDiet = function(retDataList) {
		var widgDataList = retDataList.widgDataList;
		var appendHtml = "";

		if (typeof widgDataList == "undefined" || widgDataList == null || widgDataList == "") {
			appendHtml = "오늘의 식단";
			$('.meal_menu0021 > h2').html(appendHtml);
			$(".meal_menu0021").find('.btn_more').attr('href','javascript:');
			return false;
		} else {
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > h2").empty();
			appendHtml += widgDataList[0].widgDataSj;
			$(".widgEdit[data-id=" + retDataList.widgInfo.widgId + "] > div > h2").append(appendHtml);
		}

		// 식단 더보기 버튼
		var dietMenuId = "";
		var urlTrgt = "";
		if ( dietMenuId == "" ) {
			$(".meal_menu0021").find('.btn_more').attr('href','javascript:');
		} else {
			var sysId = "hanbom-h";
			var dietHref = "/" + sysId + "/ad/fm/foodmenu/selectFoodMenuView.do?mi=" + dietMenuId;
			$(".meal_menu0021").find('.btn_more').attr('href', dietHref);
			$(".meal_menu0021").find('.btn_more').attr('target', urlTrgt);
		}
	}



/* ==========================================================================================
 * ↑ 콜백 함수
 * ------------------------------------------------------------------------------------------
 * ↓ 동적 호출 함수
 * ========================================================================================== */



//일반 게시판 동적 호출 (각 템플릿 별 .notice30XX 번호는 변화하니 맞춰서 수정할것) [BBS 1/2]
 function nttListAction(widgId){
 	
 	var clasNm = "";
 	if (widgId == "30") {
 		clasNm = ".notice0021 .setNoticeWidg";
 	} else if (widgId == "31") {
 		//clasNm = ".notice0021 .setNoticeWidg";
 	}
 	
 	$(clasNm).each(function(index, item){
 		if ($(item).attr("data-bbs") != null && $(item).attr("data-bbs") != "0") {
 			var thisObj = $(item);
 			var bbsId = $(item).attr("data-bbs");
 			var nttCount = $(item).attr("data-row");
 			var sysId = "hanbom-h";

 			$.ajax({
 				type : "post",
 				dataType : "json",
 				url : "/"+ sysId +"/wm/widg/selectWidgDataList.do",
 				data : {
 					bbsId : bbsId,
 					nttCount : nttCount,
 					sqlId : 'selectNttListByBbsId'
 				},
 				success : function(result){
 					var currObj = $(".tabWrap");
 					var addData = "";
 					
 					if (result.length > 0) {
 						if(index == 0){
 							addData += "<div class='list_box on' id='notice"+ Number(index+1) + "'>";
 						}else{
 							addData += "<div class='list_box' id='notice"+ Number(index+1) + "'>";
 						}
 						
 						addData += "<ul>";
 						for (idx = 0; idx < result.length; idx++) {
 							var nttCn = result[idx].nttCn;
 							var mi = result[idx].menuId;
 							
 							addData += "<li>";
 							if (result[idx].newCheck == "Y") {
 								addData += "	<a class='new' href='/" + sysId + "/na/ntt/selectNttInfo.do?mi=" + mi + "&nttSn=" + result[idx].nttSn + "&bbsId=" + bbsId + "'>";
 							}else{
 								addData += "	<a href='/" + sysId + "/na/ntt/selectNttInfo.do?mi=" + mi + "&nttSn=" + result[idx].nttSn + "&bbsId=" + bbsId + "'>";
 							}
 							
 							addData += "	<span class='date'>"+result[idx].regDt2+"."+result[idx].regDt3+"</span>";
 							addData += "	<p class='tit'>"+result[idx].nttSj+"</p>";
 							addData += "	<p class='txt'>"+result[idx].nttCn+"</p>";
 							addData += "</a>";
 							addData += "</li>";
 						}
 						addData += "</ul>";
 						addData += "<a href='/" + sysId + "/na/ntt/selectNttList.do?mi=" + result[0].menuId + "&bbsId=" + bbsId + "' target='_blank' class='btn_more btnTy1' title='"+result[0].bbsSj+" 더보기'><em>더보기</em><img src='/images/template/T0021/main/0021_btn_more.png' alt=''></a>";
 						addData += "</div>";
 					}else{
 						if(index == 0){
 							addData += "<div class='list_box on' id='notice"+ Number(index+1) + "'>";
 						}else{
 							addData += "<div class='list_box' id='notice"+ Number(index+1) + "'>";
 						}
 						addData += "<ul>";
 						addData += "	<li class='no_data'>데이터가 없습니다.</li>";
 						addData += "</ul>";
 						addData += "</div>";
 					}
 					currObj.append(addData);
 				},
 				error:function(data){
 					alert("오류가 발생하였습니다.\n관리자에게 문의하세요.");
 				}
 			});
 		}
 	});
 };

// 다른 일반 게시판 클릭시 current처리  // target="" 를 넣어야 최상위로 이동하지 않음 [BBS 2/2]
$(document).on('click',".notice0021 h2 a",function(){
	$(".notice0021").find(".current").removeClass("current");
	$(this).addClass("current");
	$(".notice0021").children().hide();
	$(".notice0021 h2").show();
	$(this).parent().show();
	$(this).parent().next().show();
});

$(document).on('click',".notice0021 h2 a",function(){
	$(".notice0021").find(".current").removeClass("current");
	$(this).addClass("current");
	$(".notice0021").children().hide();
	$(".notice0021 h2").show();
	$(this).parent().show();
	$(this).parent().next().show();
});

//사진, 갤러리 게시판 동적 호출 [galBbs 1/1]
function galNttListAction(widgDataList){
	var bbsId = $(".gallery0021").find(".setNoticeWidg").attr("data-bbs");
	var nttCount = $(".gallery0021").find(".setNoticeWidg").attr("data-row");
	var sysId = 'hanbom-h';

	if (bbsId != null && bbsId != "0") {
		$.ajax({
			type : "post",
			dataType : "json",
			url : "/" + sysId + "/wm/widg/selectWidgDataList.do",
			data : {
				bbsId :bbsId,
				nttCount : nttCount,
				sqlId : 'selectNttListByBbsId'
			},
			success : function(result){
				var addData = "";
				if (result.length > 0) {
					var currObj = $(".gallery0021").find(".list_box");
					addData += "<ul>";
					for (idx=0; idx < result.length; idx++) {
						var mi = result[idx].menuId;
						var thumUseAt = result[idx].thumbUseYn; //썸네일사용여부, 미사용일경우 비공개 이미지가 나오게 설정
						addData +=	"<li>";
						addData += "	<a href='/" + sysId + "/na/ntt/selectNttInfo.do?mi=" + mi + "&nttSn=" + result[idx].nttSn + "&bbsId=" + bbsId + "'>";
						if(result[idx].thumbFilpth == 'noImg'){
							addData += "	<p class='img private'><em><i class='xi-lock-o' aria-hidden='true'></i><br>미리보기 이미지가 없습니다.</em></p>";							
						}else if(thumUseAt == 'N'){
							addData += "	<p class='img private'><em><i class='xi-lock-o' aria-hidden='true'></i><br>비공개 이미지 입니다.</em></p>";	
						}else{
							addData += "	<p class='img'><img src='" + result[idx].thumbFilpth + "' alt='" + result[idx].nttSj + "'></p>";
						 }
						 addData += "	<p class='txt'><span>"+result[idx].nttSj+"</span></p>";
						 addData += "	</a>";
						 addData += "</li>";
					}
					addData += "</ul>";
					currObj.append(addData);
					$(".gallery0021").find(".btn_more").attr("href", "/" + sysId + "/na/ntt/selectNttList.do?mi=" + result[0].menuId + "&bbsId=" + bbsId).attr("target", "_blank");
				} else {
					var addData = "";
					addData += "<ul>";
					addData += "	<li class='no_data'>데이터가 없습니다.</li>";
					addData += "</ul>";
					$(".gallery0021 > .list_box").append(addData);
					$(".gallery0021").find(".btn_more").remove();
				}
				
			},

			error:function(data){
				alert("오류가 발생하였습니다.\n관리자에게 문의하세요.");
			}
		});
	}
};

//달력 세팅
function setCalenDar(actM) {
	var date = new Date(); 
	var y = $("#sYear").val();
	var m = $("#sMonth").val();
	var d = date.getDate();
	
	if ( actM != "curM" ) {
		var full_m = "";
		
	 	if ( actM == 'preM' ) { // 이전 월
	 		m--;
	 		
	 		if ( m < 1 ) {
	 			y--;
	 			m = 12;
	 		}
	 		
	 		full_m = m;
	 		
	 		if ( full_m < 10 ) {
	 			full_m = "0" + m;
	 		}
	 	}
	 	
	 	if ( actM == 'nextM' ) { // 다음 월
	 		m++;
	 		
	 		if (m > 12) {
	 			y++;
	 			m = 1;
	 		}
	 		
	 		full_m = m;
	 		
	 		if (full_m < 10) {
	 			full_m = "0" + m;
	 		}		
	 	}
	 	
		var thisDate = "" + y + ". <em>" + full_m + "</em>";
		$(".pop_schedule0021 > div > span").html(thisDate); // 년, 월 세팅
		//$(".sche_table > table > tbody").children().remove(); // 날짜 삭제
		
		$("#sYear").val(y);
		$("#sMonth").val(m);
		
		var preVal = m-1;
		var nextVal = m+1;
		
		if ( preVal < 10 ) { // 이전 월
			if ( preVal < 1 ) {
				preVal = 12;
			} else {
				preVal = "0" + preVal;
			}
		}
		
		if ( nextVal < 10 ) { // 다음 월
			nextVal = "0" + nextVal;
		} else {
			if ( nextVal == 13 ) {
				nextVal = "01";
			}
		}
		
		//$(".pop_schedule0021").find(".prev").text(preVal); // 필요시 사용
		//$(".pop_schedule0021").find(".next").text(nextVal); // 필요시 사용
	
	} else if ( actM == "curM" ) {
		var thisDate = "" + y + ".<em>" + (m < 10 ? "0" + m : m) + "</em>";
		$(".pop_schedule0021 > div > span").html(thisDate); // 년, 월 세팅
	}
	
	var theDate = new Date(y,m-1,1);
	var theDay = theDate.getDay();
	var last = [0,31,28,31,30,31,30,31,31,30,31,30,31]; 
	
	
	// 4년마다 있는 윤년을 계산합니다.
	if ((y % 4 == 0 && y % 100 !=0) || y % 400 == 0) {
		last[2] = 29;
	}

 	var lastDate = last[Number(m)];
	
	var row = Math.ceil((theDay+lastDate)/7);
	var calendar = "";
	var dNum = 1;
	var realDate = date.getFullYear() + "/" + (date.getMonth() + 1);
	var selDate = y + "/" + m;
	
	$('.sche_wrap > div > ul > li').remove();
	
	calendar += "";
	// 달력 일 세팅
	for (var i = 1; i <= row; i++) {
		
		for (var k= 1; k <= 7; k++) {
			if(i == 1 && k <= theDay || dNum > lastDate) {
				calendar += "";
			} else {
				if (k==1) {
					calendar += "<li id = 'dateTd"+dNum+"'><a id ='aChkDate"+dNum+"' class='sun'>" + dNum + "</a></li>";
				} else if (k==7) {
					calendar += "<li id = 'dateTd"+dNum+"'><a id ='aChkDate"+dNum+"' class='sat'>" + dNum + "</a></li>";
				}else if(realDate == selDate && dNum == d){
					calendar += "<li id = 'dateTd"+dNum+"'><a id ='aChkDate"+dNum+"' class='today'>" + dNum + "</a></li>";
				}else {
					calendar += "<li id = 'dateTd"+dNum+"'><a id ='aChkDate"+dNum+"' class=''>" + dNum + "</a></li>";	
				}
					dNum++;
			}
		}
	
	}
	calendar += "";
	
	$('.sche_wrap > div > ul').append(calendar);
	selectScheduleInfo(actM,y,m); 
};

//일정 세팅
function selectScheduleInfo( paraAct, paraY, paraM ) {
	var sysId = "hanbom-h";
	var mi = "17250";
	var urlTrgt = "_self";
	var schdulInfoAt = "Y";
	var srchDate = "";
	var dayArr = "";
	var dayArrObj = "";
	
	paraM = (paraM < 10 ? "0" + paraM : paraM);
	srchDate = paraY + "/" + paraM;

	if ( schdulInfoAt == "Y" ) {
		if (mi == "") {
			$(".lst").html("<li class='no_data'>연결된 일정메뉴가 없습니다.</a></li>");
			return false;
		}
	} else { // 템플릿-메인미리보기 (일정상세보기)
		$(".lst").html("<li><a href=''><span>" + paraM + ".01" + "</span>일정관리 예시 입니다.</a></li>");
		return false;
	}
	
	//일정 마지막날 확인하기위해 추가
	 var last = [0,31,28,31,30,31,30,31,31,30,31,30,31];
	
	// 4년마다 있는 윤년을 계산합니다.
	if ((paraY % 4 == 0 && paraY % 100 !=0) || paraY % 400 == 0) {
		last[2] = 29;
	}
	
	var lastDate = last[Number(paraM)];
	$.ajax({
		type : "post",
		dataType : "json",
		data : {
			srchDate : srchDate,
			sysId : sysId, 
			mi : mi 
		}, 
		url : "/hanbom-h/wm/widg/selectSchdulList.do",
		success : function(schList){
				var viewScList  = "";
				
				if ( schList.length > 0 ) {
					for ( var i = 0 ; i < schList.length ; i++ ) {
					if ( schList[i].bgnde != "" ) {
						dayArr += schList[i].bgnde.substring(8,10)+",";
							var bgndeY = schList[i].bgndeY;
							var bgndeM = schList[i].bgndeM;
							var bgndeD = schList[i].bgndeD;
							var enddeY = schList[i].enddeY;
							var enddeM = schList[i].enddeM;
							var enddeD = schList[i].enddeD;
							var dayStr = "";
							
							var bgndeMDId = bgndeM + "" + bgndeD;
							var enddeMDId = enddeM + "" + enddeD;
							
							var sche_list_type2 = true;
							if ( Number(bgndeMDId) == Number(enddeMDId) ) { // 하루
								dayStr = paraM + "." + bgndeD;
								//$("#aChkDate" + Number(bgndeD)).attr("class","event");
								//$("#aChkDate" + Number(bgndeD)).attr("href","javascript:");
								//$("#aChkDate" + Number(bgndeD)).attr("onClick","javascript:selectScheduleDay('" + bgndeY + "','" + bgndeM + "','" + bgndeD + "')");
								sche_list_type2 = false;
							} else { // 하루 이상
								/* [시작~끝 보여줘야하는 위젯일때 사용] */
								//dayStr = bgndeM + "/" + bgndeD + "~" + enddeM + "/" + enddeD;
								/* [시작~끝 상관없이 현재일 보여주는 위젯일때 사용] */
								//dayStr = paraM + "/" + "1";
								
								dayStr = paraM + "." + bgndeD;
								
								var DNum = 0; // #aChkDate 뒤에 붙는 id값
								var startCnt = 0; // for문 start값
								var maxCnt = 0; // for문 end값
								
								// ex. 주석 기준 현재월은 10월
								if ( Number(paraM) == Number(bgndeM) && Number(paraM) == Number(enddeM) ) { // ex. 10/10 ~ 10/13
									startCnt = bgndeD;
									maxCnt = enddeD;
									dayStr = paraM + "." + startCnt + "~" + maxCnt;
								} else if ( Number(paraM) == Number(bgndeM) && Number(paraM) != Number(enddeM) ) { // ex. 10/10 ~ 11/13
									startCnt = bgndeD;
									maxCnt = lastDate;
									dayStr = paraM + "." + bgndeD + "~" + maxCnt;
									if(bgndeD == lastDate){
										sche_list_type2 = false;
										dayStr = paraM + "." + bgndeD;
									}
								} else if ( Number(paraM) != Number(bgndeM) && Number(paraM) == Number(enddeM) ) { // ex. 09/10 ~ 10/13
									startCnt = 1;
									maxCnt = enddeD;
									dayStr = paraM + "." + "01" + "~" + enddeD;
								} else { // ex. 09/10 ~ 11/13
									startCnt = 1;
									maxCnt = lastDate;
									dayStr = paraM + "." + "01" + "~" + maxCnt;
								}
								for ( var day = Number(startCnt); day <= Number(maxCnt); day++ ) {
									var MNum = paraM;
									var DNum = (day < 10 ? "0" + day : day);
									$("#aChkDate"+day).addClass("event");
									$("#aChkDate"+day).attr("href","javascript:");
									$("#aChkDate"+day).attr("onClick","javascript:selectScheduleDay('" + paraY + "','" + MNum + "','" + DNum + "')");
								}
							}
							
							// 상세
						var dateSeq = schList[i].schdulSeq;
						var dateInfoHref = "/" + "hanbom-h" + "/ps/schdul/selectSchdulInfo.do?mi=" + mi + "&schdulSeq=" + dateSeq;
						if(sche_list_type2){
							viewScList += "<li class='sche_list_type2'><a href='" + dateInfoHref + "' target='" + urlTrgt + "'><span class='date'>" + dayStr + "</span>" + schList[i].schdulTitle + "</a></li>";
						}else{
							viewScList += "<li><a href='" + dateInfoHref + "' target='" + urlTrgt + "'><span class='date'>" + dayStr + "</span>" + schList[i].schdulTitle + "</a></li>";
						}
					}
				}
				} else {
					viewScList += "<li class='no_data'>데이터가 없습니다.</li>";
				}
				
				// 더보기
	 		var dateHref = "/" + "hanbom-h" + "/ps/schdul/selectSchdulMainList.do?mi=" + mi;
	 		$(".pop_schedule0021").find(".btn_more").attr("href",dateHref);
	 		
	 		// 상세일정 세팅 start
			/* [달력이 아닌 위젯에서 사용 : 전체 상세일정 세팅] */
			$(".lst").html(viewScList);
			/* [달력인 위젯에서 사용] : 오늘 상세일정 세팅 */
			/* if (paraAct == "curM") {
				var today = "1";
				if (today<10) {
					paraD = "0"+ today;
				}
				selectScheduleDay(paraY, paraM, today);
			}  */
			// 상세일정 세팅 end
			},
			error : function(data){
				console.log("관리자에게 문의해주세요.");	
			}
	});
};

//현재일정 보기 (날짜 클릭시 이벤트)
function selectScheduleDay(paraY, paraM, paraD) {
	var sysId = "hanbom-h";
	var mi = "17250";
	var urlTrgt = "_self";
	
	var paraDate = paraY + "/" + paraM + "/" + paraD;
	
	//일정 마지막날 확인하기위해 추가
	 var last = [0,31,28,31,30,31,30,31,31,30,31,30,31];
	
 	// 4년마다 있는 윤년을 계산합니다.
 	if ((paraY % 4 == 0 && paraY % 100 !=0) || paraY % 400 == 0) {
		last[2] = 29;
	}
	
	 var lastDate = last[Number(paraM)];
	
	$.ajax({
			type : "POST",
		dataType : "json",
			 url : "/hanbom-h/sv/schdulView/selectSimpleSvList.do",
			data : {
				paraDate : paraDate,
					sysId : sysId
			},
		 success : function(schList){
				var viewScList  = "";
				
				if ( schList.length > 0 ) {
					for (var i = 0 ; i < schList.length ; i++){
					if(schList[i].bgnde != ""){
							var bgndeM = schList[i].bgndeM;
							var enddeM = schList[i].enddeM;
							var bgndeD = schList[i].bgndeD;
							var enddeD = schList[i].enddeD;
							
							var dayStr = "";
							var sche_list_type2 = true;
							/* [시작~끝 보여줘야하는 위젯일때 사용] */
							var bgndeMDId = bgndeM + "" + bgndeD;
							var enddeMDId = enddeM + "" + enddeD;
							if ( Number(bgndeMDId) == Number(enddeMDId) ) { // 하루
								dayStr = paraM + "." + bgndeD;
								sche_list_type2 = false;
							} else { // 다중일
								if ( Number(paraM) == Number(bgndeM) && Number(paraM) == Number(enddeM) ) { // ex. 10/10 ~ 10/13
									dayStr = paraM + "." + bgndeD + "~" + enddeD;
								} else if ( Number(paraM) == Number(bgndeM) && Number(paraM) != Number(enddeM) ) { // ex. 10/10 ~ 11/13
									dayStr = paraM + "." + bgndeD + "~" + lastDate;
									if(bgndeD == lastDate){
										sche_list_type2 = false;
										dayStr = paraM + "." + bgndeD;
									}
								} else if ( Number(paraM) != Number(bgndeM) && Number(paraM) == Number(enddeM) ) { // ex. 09/10 ~ 10/13
									dayStr = paraM + "." + "01" + "~" + enddeD;
								} else { // ex. 09/10 ~ 11/13
									dayStr = paraM + "." + "01" + "~" + lastDate;
								}
							}

				 		// 상세일정
				 		var dateSeq = schList[i].schdulSeq;
							var dateInfoHref = "/" + "hanbom-h" + "/ps/schdul/selectSchdulInfo.do?mi=" + mi + "&schdulSeq=" + dateSeq;
							if(sche_list_type2){
								viewScList += "<li class='sche_list_type2'><a href='" + dateInfoHref + "' target='" + urlTrgt + "'><span class='date'>" + dayStr + "</span>" + schList[i].schdulTitle + "</a></li>"	
							}else{
								viewScList += "<li><a href='" + dateInfoHref + "' target='" + urlTrgt + "'><span class='date'>" + dayStr + "</span>" + schList[i].schdulTitle + "</a></li>";
							}
					}
				}
				} else {
					viewScList += "<li class='no_data'>데이터가 없습니다.</a></li>"
				}
				
				$(".lst").html(viewScList);	 
			},
			error	 : function(data){
				console.log("관리자에게 문의해주세요.");	
			}
	});
};

</script>

<!-- 위젯출력 -->


			<!-- //container -->
			<!-- footer -->
			


			<!-- 퀵메뉴 -->
			


			<!-- 퀵메뉴 -->
			
			
			<!-- //퀵메뉴 -->
			<!-- //퀵메뉴 -->

			<footer id="footer">
				<div class="container">
					<div class="footer_link">
						<!--LPM_START-->
						
						<ul>
							<li><a href="/hanbom-h/iv/indvdlView/selectIndvdlView.do" ><strong>개인정보처리방침</strong></a></li>
							<li><a href="/hanbom-h/iv/indvdlView/selectVideoView.do" >영상정보처리기기운영방침</a></li>
							<li><a href="/hanbom-h/iv/indvdlView/selectCpyrhtView.do" >저작권신고</a></li>
							<li><a href="/hanbom-h/iv/indvdlView/selectEmailView.do" >이메일주소무단수집거부</a></li>
						</ul>
						<!--LPM_END-->
					</div>
					
					
					
					
					
					
						<address>
							
								<span>
									경기 수원시 권선구 호매실로 46-93 (탑동, 한봄고등학교) 한봄고등학교
								</span>
							
							<span>
								
									Tel :  (031)293-3090 / 당직실 070-7860-7489(야간,휴일)&nbsp;&nbsp;|&nbsp;&nbsp;
								
								
									Fax : (031)293-3092&nbsp;&nbsp;
								
								
							</span>
                        </address>
					
					
					<!-- 방문통계 -->
					


<div class="visitant">
	<a href="#visitantList" onclick="viewVisitCnt('hanbom-h');" class="list hash" title="방문통계 리스트">방문통계 보기<i class="xi-chart-bar" aria-hidden="true"></i></a>
</div>

<div class="lyrPop" id="visitantList">
	<div class="lyrWrap">
		<div class="tit">
			<h2>방문자 통계 리스트</h2>
		</div>
		<div class="inner">
			<ul class="visList">
				<li>오늘 방문객 <strong class="todayVisit">0명</strong></li>
				<li>전체 방문객 <strong class="totalVisit">0명</strong></li>
			</ul>
		</div>
		<a href="#visitantList" class="btnClose hashClose"><i class="xi-close" aria-hidden="true"></i><em class="hid">방문자 통계 닫기</em></a>
	</div>
</div>

<script>
// 홈페이지 하단 방문통계 뷰
function viewVisitCnt(sysId){
	$.ajax({
		type : "post",
		dataType : "json",
		url : "/" + sysId + "/st/visit/selectVisitTodayToal.do",
		data : {
			sysId : sysId
		},
		success : function(result){
			var todayLi = result.todayCount + "명";
			var totalLi = result.totalCount + "명";

			$("#visitantList ul .todayVisit").html(todayLi);
			$("#visitantList ul .totalVisit").html(totalLi);
		},
		error:function(data){
			alert("오류가 발생하였습니다.\n관리자에게 문의하세요.");
		}
	});
}
</script>
					<!-- //방문통계 -->
					
					<!-- 구글 번역 스크립트 -->
					
						
					


<div class="gbSchlTrans">
	<div id="google_translate_element"></div>
</div>
<script>
function googleTranslateElementInit() {
	  new google.translate.TranslateElement({pageLanguage: 'ko', includedLanguages: 'en,ja,zh-CN,zh-TW', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
	}
</script>
<script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
					<!-- //구글 번역 스크립트 -->
					
					
					
						<p class="copyright">Copyright © Gyeonggido Office of Education, All Right Reserved.</p>
					
					<a href="" class="btn_top" style="display: block;"><i class="xi-angle-up" aria-hidden="true"></i><em class="hid">상단이동</em></a>
				</div>
			</footer>
			
<script>



</script>



			<!-- // footer -->
		</div>
		<!-- 위젯 001 -->
		







		<!-- //위젯 001 -->
	</body>
</html>



